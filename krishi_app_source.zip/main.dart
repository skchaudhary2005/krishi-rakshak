import 'package:flutter/material.dart';
import 'language.dart';
import 'screens/disease_detection_screen.dart';

void main() => runApp(const KrishiRakshakApp());

class KrishiRakshakApp extends StatefulWidget {
  const KrishiRakshakApp({super.key});
  @override State<KrishiRakshakApp> createState()=>_AppState();
}
class _AppState extends State<KrishiRakshakApp>{
  final lang=AppLanguage();
  @override void dispose(){lang.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>LanguageScope(
    language:lang,
    child:ValueListenableBuilder<String>(
      valueListenable:lang,
      builder:(context,_,__)=>MaterialApp(
        debugShowCheckedModeBanner:false,
        title:tr(context,'app'),
        theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF2E7D32))),
        home:const DashboardScreen(),
      ),
    ),
  );
}

class DashboardScreen extends StatelessWidget{
  const DashboardScreen({super.key});
  void languagePicker(BuildContext context) async{
    final c=LanguageScope.of(context);
    final selected=await showModalBottomSheet<String>(
      context:context,
      builder:(s)=>SafeArea(child:ListView(
        shrinkWrap:true,
        children:[
          Padding(padding:const EdgeInsets.all(20),child:Text(tr(context,'selectLanguage'),style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))),
          ...languages.entries.map((e)=>RadioListTile<String>(
            value:e.key,groupValue:c.value,title:Text(e.value),
            onChanged:(v)=>Navigator.pop(s,v),
          )),
        ],
      )),
    );
    if(selected!=null){c.value=selected;if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(tr(context,'updated'))));}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:const Color(0xFFF4FAF2),
    appBar:AppBar(backgroundColor:const Color(0xFF2E7D32),foregroundColor:Colors.white,title:Text(tr(context,'app')),actions:[
      IconButton(onPressed:()=>languagePicker(context),icon:const Icon(Icons.language))
    ]),
    body:ListView(padding:const EdgeInsets.all(18),children:[
      Text(tr(context,'namaste'),style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold,color:Color(0xFF1B5E20))),
      const SizedBox(height:6),Text(tr(context,'tagline'),style:const TextStyle(color:Colors.black54)),
      const SizedBox(height:22),
      Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xFF43A047),borderRadius:BorderRadius.circular(20)),child:Row(children:[
        const Icon(Icons.offline_bolt_rounded,color:Colors.white,size:34),const SizedBox(width:14),
        Expanded(child:Text(tr(context,'offline'),style:const TextStyle(color:Colors.white,fontSize:14))),
      ])),
      const SizedBox(height:24),Text(tr(context,'protection'),style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:14),
      Card(child:ListTile(
        leading:const CircleAvatar(backgroundColor:Color(0xFFE8F5E9),child:Icon(Icons.local_florist,color:Color(0xFF2E7D32))),
        title:Text(tr(context,'disease')),subtitle:Text(tr(context,'scan')),
        trailing:const Icon(Icons.chevron_right),
        onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const DiseaseDetectionScreen())),
      )),
      const SizedBox(height:12),
      Card(child:ListTile(
        leading:const Icon(Icons.language,color:Color(0xFF2E7D32)),
        title:Text(tr(context,'language')),subtitle:Text(languages[LanguageScope.of(context).value]!),
        trailing:const Icon(Icons.chevron_right),onTap:()=>languagePicker(context),
      )),
    ]),
    bottomNavigationBar:NavigationBar(selectedIndex:0,onDestinationSelected:(i){
      if(i==1)Navigator.push(context,MaterialPageRoute(builder:(_)=>const DiseaseDetectionScreen()));
      if(i==3)languagePicker(context);
    },destinations:[
      NavigationDestination(icon:const Icon(Icons.home_outlined),selectedIcon:const Icon(Icons.home),label:tr(context,'home')),
      NavigationDestination(icon:const Icon(Icons.camera_alt_outlined),selectedIcon:const Icon(Icons.camera_alt),label:tr(context,'detect')),
      NavigationDestination(icon:const Icon(Icons.history_outlined),selectedIcon:const Icon(Icons.history),label:tr(context,'history')),
      NavigationDestination(icon:const Icon(Icons.settings_outlined),selectedIcon:const Icon(Icons.settings),label:tr(context,'settings')),
    ]),
  );
}
